package cn.luischen.service.relation;

/**
 * 关联关系
 * Created by Donghua.Chen on 2018/4/30.
 */
public interface RelationShipService {


}
